﻿namespace MinutPapillon
{
    partial class CU_ColorBt
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.gb_GestionColorBt = new System.Windows.Forms.GroupBox();
            this.cb_RandomButton = new System.Windows.Forms.CheckBox();
            this.BtFont11 = new System.Windows.Forms.Button();
            this.BtFont9 = new System.Windows.Forms.Button();
            this.BtFont13 = new System.Windows.Forms.Button();
            this.BtFont7 = new System.Windows.Forms.Button();
            this.BtFont4 = new System.Windows.Forms.Button();
            this.BtFont1 = new System.Windows.Forms.Button();
            this.BtFont10 = new System.Windows.Forms.Button();
            this.BtFont8 = new System.Windows.Forms.Button();
            this.BtFont6 = new System.Windows.Forms.Button();
            this.BtFont5 = new System.Windows.Forms.Button();
            this.BtFont2 = new System.Windows.Forms.Button();
            this.BtFont3 = new System.Windows.Forms.Button();
            this.BtFont12 = new System.Windows.Forms.Button();
            this.BtType12 = new System.Windows.Forms.Button();
            this.BtType1 = new System.Windows.Forms.Button();
            this.BtType7 = new System.Windows.Forms.Button();
            this.BtType11 = new System.Windows.Forms.Button();
            this.BtType10 = new System.Windows.Forms.Button();
            this.BtType9 = new System.Windows.Forms.Button();
            this.BtType8 = new System.Windows.Forms.Button();
            this.BtType13 = new System.Windows.Forms.Button();
            this.BtType6 = new System.Windows.Forms.Button();
            this.BtType5 = new System.Windows.Forms.Button();
            this.BtType4 = new System.Windows.Forms.Button();
            this.BtType3 = new System.Windows.Forms.Button();
            this.BtType2 = new System.Windows.Forms.Button();
            this.bt_SaveColor = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.lb_Infos = new System.Windows.Forms.Label();
            this.gb_GestionColorBt.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_GestionColorBt
            // 
            this.gb_GestionColorBt.BackColor = System.Drawing.Color.Transparent;
            this.gb_GestionColorBt.Controls.Add(this.lb_Infos);
            this.gb_GestionColorBt.Controls.Add(this.cb_RandomButton);
            this.gb_GestionColorBt.Controls.Add(this.BtFont11);
            this.gb_GestionColorBt.Controls.Add(this.BtFont9);
            this.gb_GestionColorBt.Controls.Add(this.BtFont13);
            this.gb_GestionColorBt.Controls.Add(this.BtFont7);
            this.gb_GestionColorBt.Controls.Add(this.BtFont4);
            this.gb_GestionColorBt.Controls.Add(this.BtFont1);
            this.gb_GestionColorBt.Controls.Add(this.BtFont10);
            this.gb_GestionColorBt.Controls.Add(this.BtFont8);
            this.gb_GestionColorBt.Controls.Add(this.BtFont6);
            this.gb_GestionColorBt.Controls.Add(this.BtFont5);
            this.gb_GestionColorBt.Controls.Add(this.BtFont2);
            this.gb_GestionColorBt.Controls.Add(this.BtFont3);
            this.gb_GestionColorBt.Controls.Add(this.BtFont12);
            this.gb_GestionColorBt.Controls.Add(this.BtType12);
            this.gb_GestionColorBt.Controls.Add(this.BtType1);
            this.gb_GestionColorBt.Controls.Add(this.BtType7);
            this.gb_GestionColorBt.Controls.Add(this.BtType11);
            this.gb_GestionColorBt.Controls.Add(this.BtType10);
            this.gb_GestionColorBt.Controls.Add(this.BtType9);
            this.gb_GestionColorBt.Controls.Add(this.BtType8);
            this.gb_GestionColorBt.Controls.Add(this.BtType13);
            this.gb_GestionColorBt.Controls.Add(this.BtType6);
            this.gb_GestionColorBt.Controls.Add(this.BtType5);
            this.gb_GestionColorBt.Controls.Add(this.BtType4);
            this.gb_GestionColorBt.Controls.Add(this.BtType3);
            this.gb_GestionColorBt.Controls.Add(this.BtType2);
            this.gb_GestionColorBt.Controls.Add(this.bt_SaveColor);
            this.gb_GestionColorBt.ForeColor = System.Drawing.Color.White;
            this.gb_GestionColorBt.Location = new System.Drawing.Point(10, 3);
            this.gb_GestionColorBt.Name = "gb_GestionColorBt";
            this.gb_GestionColorBt.Size = new System.Drawing.Size(250, 339);
            this.gb_GestionColorBt.TabIndex = 5;
            this.gb_GestionColorBt.TabStop = false;
            this.gb_GestionColorBt.Text = "Colorisation des type de boutons";
            // 
            // cb_RandomButton
            // 
            this.cb_RandomButton.AutoSize = true;
            this.cb_RandomButton.Location = new System.Drawing.Point(11, 277);
            this.cb_RandomButton.Name = "cb_RandomButton";
            this.cb_RandomButton.Size = new System.Drawing.Size(230, 17);
            this.cb_RandomButton.TabIndex = 33;
            this.cb_RandomButton.Text = "Modifier aleatoirement l\'ordre des boutons ?";
            this.cb_RandomButton.UseVisualStyleBackColor = true;
            // 
            // BtFont11
            // 
            this.BtFont11.BackColor = System.Drawing.Color.White;
            this.BtFont11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont11.ForeColor = System.Drawing.Color.Black;
            this.BtFont11.Location = new System.Drawing.Point(222, 199);
            this.BtFont11.Name = "BtFont11";
            this.BtFont11.Size = new System.Drawing.Size(25, 25);
            this.BtFont11.TabIndex = 29;
            this.BtFont11.Text = "t";
            this.BtFont11.UseVisualStyleBackColor = false;
            this.BtFont11.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont9
            // 
            this.BtFont9.BackColor = System.Drawing.Color.White;
            this.BtFont9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont9.ForeColor = System.Drawing.Color.Black;
            this.BtFont9.Location = new System.Drawing.Point(222, 163);
            this.BtFont9.Name = "BtFont9";
            this.BtFont9.Size = new System.Drawing.Size(25, 25);
            this.BtFont9.TabIndex = 25;
            this.BtFont9.Text = "t";
            this.BtFont9.UseVisualStyleBackColor = false;
            this.BtFont9.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont13
            // 
            this.BtFont13.BackColor = System.Drawing.Color.White;
            this.BtFont13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont13.ForeColor = System.Drawing.Color.Black;
            this.BtFont13.Location = new System.Drawing.Point(222, 127);
            this.BtFont13.Name = "BtFont13";
            this.BtFont13.Size = new System.Drawing.Size(25, 25);
            this.BtFont13.TabIndex = 21;
            this.BtFont13.Text = "t";
            this.BtFont13.UseVisualStyleBackColor = false;
            this.BtFont13.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont7
            // 
            this.BtFont7.BackColor = System.Drawing.Color.White;
            this.BtFont7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont7.ForeColor = System.Drawing.Color.Black;
            this.BtFont7.Location = new System.Drawing.Point(222, 91);
            this.BtFont7.Name = "BtFont7";
            this.BtFont7.Size = new System.Drawing.Size(25, 25);
            this.BtFont7.TabIndex = 17;
            this.BtFont7.Text = "t";
            this.BtFont7.UseVisualStyleBackColor = false;
            this.BtFont7.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont4
            // 
            this.BtFont4.BackColor = System.Drawing.Color.White;
            this.BtFont4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont4.ForeColor = System.Drawing.Color.Black;
            this.BtFont4.Location = new System.Drawing.Point(222, 55);
            this.BtFont4.Name = "BtFont4";
            this.BtFont4.Size = new System.Drawing.Size(25, 25);
            this.BtFont4.TabIndex = 13;
            this.BtFont4.Text = "t";
            this.BtFont4.UseVisualStyleBackColor = false;
            this.BtFont4.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont1
            // 
            this.BtFont1.BackColor = System.Drawing.Color.White;
            this.BtFont1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont1.ForeColor = System.Drawing.Color.Black;
            this.BtFont1.Location = new System.Drawing.Point(101, 235);
            this.BtFont1.Name = "BtFont1";
            this.BtFont1.Size = new System.Drawing.Size(25, 25);
            this.BtFont1.TabIndex = 31;
            this.BtFont1.Text = "t";
            this.BtFont1.UseVisualStyleBackColor = false;
            this.BtFont1.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont10
            // 
            this.BtFont10.BackColor = System.Drawing.Color.White;
            this.BtFont10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont10.ForeColor = System.Drawing.Color.Black;
            this.BtFont10.Location = new System.Drawing.Point(101, 199);
            this.BtFont10.Name = "BtFont10";
            this.BtFont10.Size = new System.Drawing.Size(25, 25);
            this.BtFont10.TabIndex = 27;
            this.BtFont10.Text = "t";
            this.BtFont10.UseVisualStyleBackColor = false;
            this.BtFont10.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont8
            // 
            this.BtFont8.BackColor = System.Drawing.Color.White;
            this.BtFont8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont8.ForeColor = System.Drawing.Color.Black;
            this.BtFont8.Location = new System.Drawing.Point(101, 163);
            this.BtFont8.Name = "BtFont8";
            this.BtFont8.Size = new System.Drawing.Size(25, 25);
            this.BtFont8.TabIndex = 23;
            this.BtFont8.Text = "t";
            this.BtFont8.UseVisualStyleBackColor = false;
            this.BtFont8.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont6
            // 
            this.BtFont6.BackColor = System.Drawing.Color.White;
            this.BtFont6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont6.ForeColor = System.Drawing.Color.Black;
            this.BtFont6.Location = new System.Drawing.Point(101, 127);
            this.BtFont6.Name = "BtFont6";
            this.BtFont6.Size = new System.Drawing.Size(25, 25);
            this.BtFont6.TabIndex = 19;
            this.BtFont6.Text = "t";
            this.BtFont6.UseVisualStyleBackColor = false;
            this.BtFont6.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont5
            // 
            this.BtFont5.BackColor = System.Drawing.Color.White;
            this.BtFont5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont5.ForeColor = System.Drawing.Color.Black;
            this.BtFont5.Location = new System.Drawing.Point(101, 91);
            this.BtFont5.Name = "BtFont5";
            this.BtFont5.Size = new System.Drawing.Size(25, 25);
            this.BtFont5.TabIndex = 15;
            this.BtFont5.Text = "t";
            this.BtFont5.UseVisualStyleBackColor = false;
            this.BtFont5.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont2
            // 
            this.BtFont2.BackColor = System.Drawing.Color.White;
            this.BtFont2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont2.ForeColor = System.Drawing.Color.Black;
            this.BtFont2.Location = new System.Drawing.Point(222, 19);
            this.BtFont2.Name = "BtFont2";
            this.BtFont2.Size = new System.Drawing.Size(25, 25);
            this.BtFont2.TabIndex = 9;
            this.BtFont2.Text = "t";
            this.BtFont2.UseVisualStyleBackColor = false;
            this.BtFont2.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont3
            // 
            this.BtFont3.BackColor = System.Drawing.Color.White;
            this.BtFont3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont3.ForeColor = System.Drawing.Color.Black;
            this.BtFont3.Location = new System.Drawing.Point(101, 55);
            this.BtFont3.Name = "BtFont3";
            this.BtFont3.Size = new System.Drawing.Size(25, 25);
            this.BtFont3.TabIndex = 11;
            this.BtFont3.Text = "t";
            this.BtFont3.UseVisualStyleBackColor = false;
            this.BtFont3.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtFont12
            // 
            this.BtFont12.BackColor = System.Drawing.Color.White;
            this.BtFont12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtFont12.ForeColor = System.Drawing.Color.Black;
            this.BtFont12.Location = new System.Drawing.Point(101, 19);
            this.BtFont12.Name = "BtFont12";
            this.BtFont12.Size = new System.Drawing.Size(25, 25);
            this.BtFont12.TabIndex = 7;
            this.BtFont12.Text = "t";
            this.BtFont12.UseVisualStyleBackColor = false;
            this.BtFont12.Click += new System.EventHandler(this.BtFontColor_Click);
            // 
            // BtType12
            // 
            this.BtType12.ForeColor = System.Drawing.Color.Black;
            this.BtType12.Location = new System.Drawing.Point(6, 19);
            this.BtType12.Name = "BtType12";
            this.BtType12.Size = new System.Drawing.Size(110, 30);
            this.BtType12.TabIndex = 6;
            this.BtType12.Text = "SAUCE";
            this.BtType12.UseVisualStyleBackColor = true;
            this.BtType12.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType1
            // 
            this.BtType1.ForeColor = System.Drawing.Color.Black;
            this.BtType1.Location = new System.Drawing.Point(6, 235);
            this.BtType1.Name = "BtType1";
            this.BtType1.Size = new System.Drawing.Size(110, 30);
            this.BtType1.TabIndex = 30;
            this.BtType1.Text = "AUCUN";
            this.BtType1.UseVisualStyleBackColor = true;
            this.BtType1.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType7
            // 
            this.BtType7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtType7.ForeColor = System.Drawing.Color.Black;
            this.BtType7.Location = new System.Drawing.Point(131, 91);
            this.BtType7.Name = "BtType7";
            this.BtType7.Size = new System.Drawing.Size(110, 30);
            this.BtType7.TabIndex = 16;
            this.BtType7.Text = "DESSERT";
            this.BtType7.UseVisualStyleBackColor = true;
            this.BtType7.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType11
            // 
            this.BtType11.ForeColor = System.Drawing.Color.Black;
            this.BtType11.Location = new System.Drawing.Point(131, 199);
            this.BtType11.Name = "BtType11";
            this.BtType11.Size = new System.Drawing.Size(110, 30);
            this.BtType11.TabIndex = 28;
            this.BtType11.Text = "FRUIT";
            this.BtType11.UseVisualStyleBackColor = true;
            this.BtType11.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType10
            // 
            this.BtType10.ForeColor = System.Drawing.Color.Black;
            this.BtType10.Location = new System.Drawing.Point(6, 199);
            this.BtType10.Name = "BtType10";
            this.BtType10.Size = new System.Drawing.Size(110, 30);
            this.BtType10.TabIndex = 26;
            this.BtType10.Text = "LEGUME";
            this.BtType10.UseVisualStyleBackColor = true;
            this.BtType10.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType9
            // 
            this.BtType9.ForeColor = System.Drawing.Color.Black;
            this.BtType9.Location = new System.Drawing.Point(131, 163);
            this.BtType9.Name = "BtType9";
            this.BtType9.Size = new System.Drawing.Size(110, 30);
            this.BtType9.TabIndex = 24;
            this.BtType9.Text = "POISSON";
            this.BtType9.UseVisualStyleBackColor = true;
            this.BtType9.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType8
            // 
            this.BtType8.ForeColor = System.Drawing.Color.Black;
            this.BtType8.Location = new System.Drawing.Point(6, 163);
            this.BtType8.Name = "BtType8";
            this.BtType8.Size = new System.Drawing.Size(110, 30);
            this.BtType8.TabIndex = 22;
            this.BtType8.Text = "VIANDE";
            this.BtType8.UseVisualStyleBackColor = true;
            this.BtType8.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType13
            // 
            this.BtType13.ForeColor = System.Drawing.Color.Black;
            this.BtType13.Location = new System.Drawing.Point(131, 127);
            this.BtType13.Name = "BtType13";
            this.BtType13.Size = new System.Drawing.Size(110, 30);
            this.BtType13.TabIndex = 20;
            this.BtType13.Text = "PAIN";
            this.BtType13.UseVisualStyleBackColor = true;
            this.BtType13.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType6
            // 
            this.BtType6.ForeColor = System.Drawing.Color.Black;
            this.BtType6.Location = new System.Drawing.Point(6, 127);
            this.BtType6.Name = "BtType6";
            this.BtType6.Size = new System.Drawing.Size(110, 30);
            this.BtType6.TabIndex = 18;
            this.BtType6.Text = "FROMAGE";
            this.BtType6.UseVisualStyleBackColor = true;
            this.BtType6.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType5
            // 
            this.BtType5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtType5.ForeColor = System.Drawing.Color.Black;
            this.BtType5.Location = new System.Drawing.Point(6, 91);
            this.BtType5.Name = "BtType5";
            this.BtType5.Size = new System.Drawing.Size(110, 30);
            this.BtType5.TabIndex = 14;
            this.BtType5.Text = "PLAT PRINCIPAL";
            this.BtType5.UseVisualStyleBackColor = true;
            this.BtType5.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType4
            // 
            this.BtType4.ForeColor = System.Drawing.Color.Black;
            this.BtType4.Location = new System.Drawing.Point(131, 55);
            this.BtType4.Name = "BtType4";
            this.BtType4.Size = new System.Drawing.Size(110, 30);
            this.BtType4.TabIndex = 12;
            this.BtType4.Text = "ENTREE CHAUDE";
            this.BtType4.UseVisualStyleBackColor = true;
            this.BtType4.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType3
            // 
            this.BtType3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtType3.ForeColor = System.Drawing.Color.Black;
            this.BtType3.Location = new System.Drawing.Point(6, 55);
            this.BtType3.Name = "BtType3";
            this.BtType3.Size = new System.Drawing.Size(110, 30);
            this.BtType3.TabIndex = 10;
            this.BtType3.Text = "ENTREE FROIDE";
            this.BtType3.UseVisualStyleBackColor = true;
            this.BtType3.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // BtType2
            // 
            this.BtType2.ForeColor = System.Drawing.Color.Black;
            this.BtType2.Location = new System.Drawing.Point(129, 19);
            this.BtType2.Name = "BtType2";
            this.BtType2.Size = new System.Drawing.Size(110, 30);
            this.BtType2.TabIndex = 8;
            this.BtType2.Text = "BOISSONS";
            this.BtType2.UseVisualStyleBackColor = true;
            this.BtType2.Click += new System.EventHandler(this.BtColor_Click);
            // 
            // bt_SaveColor
            // 
            this.bt_SaveColor.BackColor = System.Drawing.Color.Transparent;
            this.bt_SaveColor.BackgroundImage = global::MinutPapillon.Properties.Resources.BGButton;
            this.bt_SaveColor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_SaveColor.ForeColor = System.Drawing.Color.Black;
            this.bt_SaveColor.Location = new System.Drawing.Point(6, 304);
            this.bt_SaveColor.Name = "bt_SaveColor";
            this.bt_SaveColor.Size = new System.Drawing.Size(235, 29);
            this.bt_SaveColor.TabIndex = 32;
            this.bt_SaveColor.Text = "ENREGISTRER MODIFICATIONS";
            this.bt_SaveColor.UseVisualStyleBackColor = false;
            this.bt_SaveColor.Click += new System.EventHandler(this.bt_SaveColor_Click);
            // 
            // lb_Infos
            // 
            this.lb_Infos.AutoSize = true;
            this.lb_Infos.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Infos.Location = new System.Drawing.Point(129, 235);
            this.lb_Infos.Name = "lb_Infos";
            this.lb_Infos.Size = new System.Drawing.Size(122, 30);
            this.lb_Infos.TabIndex = 34;
            this.lb_Infos.Text = "* Les couleurs des boutons\r\ndes menus sont soulignés !\r\n";
            // 
            // CU_ColorBt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gb_GestionColorBt);
            this.MinimumSize = new System.Drawing.Size(270, 350);
            this.Name = "CU_ColorBt";
            this.Size = new System.Drawing.Size(270, 350);
            this.Load += new System.EventHandler(this.CU_ColorBt_Load);
            this.gb_GestionColorBt.ResumeLayout(false);
            this.gb_GestionColorBt.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_GestionColorBt;
        private System.Windows.Forms.Button bt_SaveColor;
        private System.Windows.Forms.Button BtType11;
        private System.Windows.Forms.Button BtType10;
        private System.Windows.Forms.Button BtType9;
        private System.Windows.Forms.Button BtType8;
        private System.Windows.Forms.Button BtType13;
        private System.Windows.Forms.Button BtType7;
        private System.Windows.Forms.Button BtType6;
        private System.Windows.Forms.Button BtType5;
        private System.Windows.Forms.Button BtType4;
        private System.Windows.Forms.Button BtType3;
        private System.Windows.Forms.Button BtType2;
        private System.Windows.Forms.Button BtType1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button BtType12;
        private System.Windows.Forms.Button BtFont11;
        private System.Windows.Forms.Button BtFont9;
        private System.Windows.Forms.Button BtFont13;
        private System.Windows.Forms.Button BtFont7;
        private System.Windows.Forms.Button BtFont4;
        private System.Windows.Forms.Button BtFont1;
        private System.Windows.Forms.Button BtFont10;
        private System.Windows.Forms.Button BtFont8;
        private System.Windows.Forms.Button BtFont6;
        private System.Windows.Forms.Button BtFont5;
        private System.Windows.Forms.Button BtFont2;
        private System.Windows.Forms.Button BtFont3;
        private System.Windows.Forms.Button BtFont12;
        private System.Windows.Forms.CheckBox cb_RandomButton;
        private System.Windows.Forms.Label lb_Infos;
    }
}
