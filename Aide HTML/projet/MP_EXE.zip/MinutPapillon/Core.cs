﻿using System;

    public class Error
    {
        #region FONCTION DE GESTION D'ERREURS GENEREES VIA DES REQUETES SQL
        public void SQL_Error(SqlException ex)
        {
            MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        #endregion

        #region FONCTION DE GESTION D'ERREURS GENEREES PAR LE CODE SOURCE DE L'APPLICATION
        public void C_Error(Exception ex)
        {
            MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        #endregion
    }

    public class WinForm
    {
        public void KeyPress(object sender, KeyPressEventArgs e)
        {
            if ( (e.KeyChar == (char)Keys.Enter) || (e.KeyChar == 13) )
            {
                    MessageBox.Show("Touche entrée pressée");
                    //Fonction_
            }
        }
    }
        

